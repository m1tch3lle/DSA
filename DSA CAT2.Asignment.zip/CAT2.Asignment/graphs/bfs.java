import java.util.*;

class Edge implements Comparable<Edge> {
    int v1, v2, weight;

    Edge(int v1, int v2, int weight) {
        this.v1 = v1;
        this.v2 = v2;
        this.weight = weight;
    }

    public int compareTo(Edge other) {
        return this.weight - other.weight;
    }
}

class Graph {
    int vertices;
    List<Edge> edges;

    Graph(int vertices) {
        this.vertices = vertices;
        this.edges = new ArrayList<>();
    }

    void addEdge(int v1, int v2, int weight) {
        edges.add(new Edge(v1, v2, weight));
    }

    void bfs(int start) {
        boolean[] visited = new boolean[vertices];
        Queue<Integer> queue = new LinkedList<>();

        visited[start] = true;
        queue.add(start);

        while (!queue.isEmpty()) {
            int current = queue.poll();
            System.out.print(current + " ");

            for (Edge edge : edges) {
                if (edge.v1 == current && !visited[edge.v2]) {
                    visited[edge.v2] = true;
                    queue.add(edge.v2);
                } else if (edge.v2 == current && !visited[edge.v1]) {
                    visited[edge.v1] = true;
                    queue.add(edge.v1);
                }
            }
        }
    }

    void findMST() {
        Collections.sort(edges);
        UnionFind uf = new UnionFind(vertices);

        for (Edge edge : edges) {
            if (!uf.isConnected(edge.v1, edge.v2)) {
                uf.union(edge.v1, edge.v2);
                System.out.println("Edge (" + edge.v1 + ", " + edge.v2 + ") with weight " + edge.weight);
            }
        }
    }
}

class UnionFind {
    int[] parent;

    UnionFind(int vertices) {
        parent = new int[vertices];
        for (int i = 0; i < vertices; i++) {
            parent[i] = i;
        }
    }

    int find(int v) {
        if (parent[v] != v) {
            parent[v] = find(parent[v]);
        }
        return parent[v];
    }

    void union(int v1, int v2) {
        int root1 = find(v1);
        int root2 = find(v2);
        if (root1 != root2) {
            parent[root1] = root2;
        }
    }

    boolean isConnected(int v1, int v2) {
        return find(v1) == find(v2);
    }
}

public class BFSMST {
    public static void main(String[] args) {
        Graph graph = new Graph(9);

        graph.addEdge(0, 1, 4);
        graph.addEdge(0, 2, 2);
        graph.addEdge(1, 2, 5);
        graph.addEdge(1, 3, 10);
        graph.addEdge(2, 3, 3);
        graph.addEdge(2, 4, 7);
        graph.addEdge(3, 4, 6);
        graph.addEdge(3, 5, 1);
        graph.addEdge(4, 5, 8);
        graph.addEdge(5, 6, 9);
        graph.addEdge(5, 7, 11);
        graph.addEdge(6, 7, 12);
        graph.addEdge(6, 8, 13);
        graph.addEdge(7, 8, 14);

        System.out.println("BFS traversal starting from vertex 0:");
        graph.bfs(0);

        System.out.println("\nMinimum Spanning Tree:");
        graph.findMST();
    }
}