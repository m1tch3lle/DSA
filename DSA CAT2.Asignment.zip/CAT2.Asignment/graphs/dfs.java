import java.util.*;

class Link {
    int vertex;
    Link next;

    Link(int vertex) {
        this.vertex = vertex;
        this.next = null;
    }
}

class LinkList {
    Link head;

    LinkList() {
        this.head = null;
    }

    void add(int vertex) {
        Link newLink = new Link(vertex);
        newLink.next = head;
        head = newLink;
    }

    boolean find(int vertex) {
        Link current = head;
        while (current != null) {
            if (current.vertex == vertex) {
                return true;
            }
            current = current.next;
        }
        return false;
    }
}

class AdjacencyList {
    LinkList[] adjacencyList;

    AdjacencyList(int vertices) {
        adjacencyList = new LinkList[vertices];
        for (int i = 0; i < vertices; i++) {
            adjacencyList[i] = new LinkList();
        }
    }

    void addEdge(int source, int destination) {
        adjacencyList[source].add(destination);
        adjacencyList[destination].add(source); // For undirected graph
    }

    boolean isEdge(int source, int destination) {
        return adjacencyList[source].find(destination);
    }
}

public class Graph {
    public static void main(String[] args) {
        int totalVertices = 5; // Example: 5 vertices
        AdjacencyList graph = new AdjacencyList(totalVertices);

        // Adding edges to the graph
        graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        graph.addEdge(1, 3);
        graph.addEdge(2, 4);

        // Checking if edges exist
        System.out.println("Edge between 0 and 1: " + graph.isEdge(0, 1));
        System.out.println("Edge between 1 and 2: " + graph.isEdge(1, 2));
        System.out.println("Edge between 2 and 3: " + graph.isEdge(2, 3));
    }
}
