/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.linkedlist2;

/**
 *
 * @author ADMIN
 */
public class LinkedListTest {
    public static void main(String[] args) {
        // Create a new linked list
        LinkedList2 linkedList = new LinkedList2();

        // Add 5 items to the linked list
        linkedList.add("Math");
        linkedList.add("Science");
        linkedList.add("History");
        linkedList.add("English");
        linkedList.add("Programming");

        // Add a head node
        linkedList.addToHead("Art");

        // Add five more nodes using the add() method
        linkedList.add("Biology");
        linkedList.add("Physics");
        linkedList.add("Geography");
        linkedList.add("Music");
        linkedList.add("Chemistry");

        // Print out the contents of the linked list
        linkedList.traverse();

        // Delete the first and second nodes
        linkedList.remove(0);
        linkedList.remove(0);

        // Add an item to index 5 in the linked list
        linkedList.add("Spanish", 5);

        // Print out the contents of the linked list
        linkedList.traverse();
    }
}
