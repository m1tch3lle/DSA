/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.binarytree;

/**
 *
 * @author ADMIN
 */
public class BinaryTree {
    private Node root;

    public BinaryTree() {
        root = null;
    }

    public boolean isEmpty() {
        return root == null;
    }

    public void insert(int data) {
        root = insert(root, data);
    }

    private Node insert(Node node, int data) {
        if (node == null) {
            node = new Node(data);
        } else {
            if (data <= node.value) {
                node.left = insert(node.left, data);
            } else {
                node.right = insert(node.right, data);
            }
        }
        return node;
    }

    public void delete(int data) {
        if (isEmpty()) {
            System.out.println("Tree is empty");
        } else if (!search(data)) {
            System.out.println("Sorry, " + data + " is not present in the tree");
        } else {
            root = delete(root, data);
            System.out.println(data + " deleted from the tree");
        }
    }

    private Node delete(Node root, int data) {
        if (root == null) {
            return root;
        }
        if (data < root.value) {
            root.left = delete(root.left, data);
        } else if (data > root.value) {
            root.right = delete(root.right, data);
        } else {
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }
            root.value = findMin(root.right);
            root.right = delete(root.right, root.value);
        }
        return root;
    }

    public boolean search(int data) {
        return search(root, data);
    }

    private boolean search(Node node, int data) {
        if (node == null) {
            return false;
        }
        if (node.value == data) {
            return true;
        }
        return search(node.left, data) || search(node.right, data);
    }

    public int findMax() {
        return findMax(root);
    }

    private int findMax(Node node) {
        if (node == null) {
            return Integer.MIN_VALUE;
        }
        int max = node.value;
        int leftMax = findMax(node.left);
        int rightMax = findMax(node.right);
        return Math.max(max, Math.max(leftMax, rightMax));
    }

    public int findMin() {
        return findMin(root);
    }

    private int findMin(Node node) {
        if (node == null) {
            return Integer.MAX_VALUE;
        }
        int min = node.value;
        int leftMin = findMin(node.left);
        int rightMin = findMin(node.right);
        return Math.min(min, Math.min(leftMin, rightMin));
    }

    public void inorderTraversal() {
        inorderTraversal(root);
    }

    private void inorderTraversal(Node node) {
        if (node != null) {
            inorderTraversal(node.left);
            System.out.print(node.value + " ");
            inorderTraversal(node.right);
        }
    }

    public void preorderTraversal() {
        preorderTraversal(root);
    }

    private void preorderTraversal(Node node) {
        if (node != null) {
            System.out.print(node.value + " ");
            preorderTraversal(node.left);
            preorderTraversal(node.right);
        }
    }

    public void postorderTraversal() {
        postorderTraversal(root);
    }

    private void postorderTraversal(Node node) {
        if (node != null) {
            postorderTraversal(node.left);
            postorderTraversal(node.right);
            System.out.print(node.value + " ");
        }
    }

    private class Node {
        private int value;
        private Node left;
        private Node right;

        public Node(int value) {
            this.value = value;
            left = null;
            right = null;
        }
    }

    public static void main(String[] args) {
        BinarySearchTree tree = new BinarySearchTree();
        tree.insert(50);
        tree.insert(30);
        tree.insert(20);
        tree.insert(40);
        tree.insert(70);
        tree.insert(60);
        tree.insert(80);

        System.out.println("Inorder traversal:");
        tree.inorderTraversal();
        System.out.println();

        System.out.println("Preorder traversal:");
        tree.preorderTraversal();
        System.out.println();

        System.out.println("Postorder traversal:");
        tree.postorderTraversal();
        System.out.println();

        System.out.println("Searching for 50: " + tree.search(50));
        System.out.println("Searching for 34: " + tree.search(34));

        System.out.println("Maximum value: " + tree.findMax());
        System.out.println("Minimum value: " + tree.findMin());

        tree.delete(30);

        System.out.println("Inorder traversal after deleting 30:");
        tree.inorderTraversal();
        System.out.println();
    }
}
