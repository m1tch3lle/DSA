/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.queues;

/**
 *
 * @author ADMIN
 */

public class queueTest {
    public static void main(String[] args) {
        Queues queue = new Queues(10);
        System.out.println("Front index: " + queue.front);
        System.out.println("Rear index: " + queue.rear);

        for (int i = 1; i <= 10; i++) {
            queue.enqueue(i);
        }

        queue.printQueue();
        System.out.println("Front element: " + queue.peekFront());
        System.out.println("Rear element: " + queue.queArray[queue.rear]);

        System.out.println("Front index: " + queue.front);
        System.out.println("Rear index: " + queue.rear);

        for (int i = 1; i <= 3; i++) {
            queue.dequeue();
        }

        for (int i = 1; i <= 2; i++) {
            queue.enqueue(i + 10);
        }

        for (int i = 1; i <= 2; i++) {
            queue.dequeue();
        }

        queue.printQueue();
        System.out.println("Front index: " + queue.front);
        System.out.println("Rear index: " + queue.rear);

        for (int i = 1; i <= 6; i++) {
            queue.enqueue(i + 12);
        }

        queue.printQueue();
        System.out.println("Front index: " + queue.front);
        System.out.println("Rear index: " + queue.rear);

        for (int i = 1; i <= 11; i++) {
            queue.dequeue();
        }
    }
}