/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.queues;

/**
 *
 * @author ADMIN
 */
public class Queues {
    private int maxSize;
    private long[] queArray;
    private int front, rear, nItems;

    public Queues(int maxSize) {
        this.maxSize = maxSize;
        queArray = new long[maxSize];
        front = 0;
        rear = -1;
        nItems = 0;
    }

    public void enqueue(long item) {
        if (isFull()) {
            System.out.println("Queue is full. Cannot add element " + item);
        } else {
            rear = (rear + 1) % maxSize;
            queArray[rear] = item;
            nItems++;
            System.out.println("Element " + item + " added to queue at position " + (rear + 1));
        }
    }

    public long dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty. Cannot dequeue.");
            return -1;
        } else {
            long item = queArray[front];
            front = (front + 1) % maxSize;
            nItems--;
            return item;
        }
    }

    public long peekFront() {
        if (isEmpty()) {
            System.out.println("Queue is empty. Cannot peek front.");
            return -1;
        } else {
            return queArray[front];
        }
    }

    public boolean isEmpty() {
        return (nItems == 0);
    }

    public boolean isFull() {
        return (nItems == maxSize);
    }

    public int size() {
        return nItems;
    }

    public void printQueue() {
        System.out.print("Queue contents: ");
        int current = front;
        for (int i = 0; i < nItems; i++) {
            System.out.print(queArray[current] + " ");
            current = (current + 1) % maxSize;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Queues queue = new Queues(5);
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        queue.printQueue();
        System.out.println("Dequeued item: " + queue.dequeue());
        System.out.println("Dequeued item: " + queue.dequeue());
        queue.printQueue();
    }
}