/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.queues;

/**
 *
 * @author ADMIN
 */
import java.util.LinkedList;
import java.util.Queue;

public class BankQueue {
    private Queue<String> queue;
    private int customerCount;

    public BankQueue() {
        queue = new LinkedList<>();
        customerCount = 0;
    }

    public void enqueue(String customerName) {
        queue.add(customerName);
        customerCount++;
        System.out.println("Customer " + customerName + " added to the queue. Customer count: " + customerCount);
    }

    public String dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty. Cannot dequeue.");
            return null;
        } else {
            String customerName = queue.poll();
            customerCount--;
            System.out.println("Customer " + customerName + " dequeued. Customer count: " + customerCount);
            return customerName;
        }
    }

    public String peekFront() {
        if (isEmpty()) {
            System.out.println("Queue is empty. Cannot peek front.");
            return null;
        } else {
            return queue.peek();
        }
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }

    public int size() {
        return customerCount;
    }

    public void printQueue() {
        System.out.print("Queue contents: ");
        for (String customerName : queue) {
            System.out.print(customerName + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        BankQueue bankQueue = new BankQueue();
        bankQueue.enqueue("John");
        bankQueue.enqueue("Alice");
        bankQueue.enqueue("Bob");
        bankQueue.printQueue();
        System.out.println("Dequeued customer: " + bankQueue.dequeue());
        System.out.println("Dequeued customer: " + bankQueue.dequeue());
        bankQueue.printQueue();
    }
}
